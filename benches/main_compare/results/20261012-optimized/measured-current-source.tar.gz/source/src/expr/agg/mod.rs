// Copyright 2026 The Roc Contributors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! Aggregate descriptions are separate from scalar expressions.
pub(crate) mod accumulator;
mod aggregate;
#[cfg(test)]
pub(crate) mod test_support;
pub use aggregate::{AggregateExpression, AggregateFunction};

#[cfg(test)]
#[path = "tests/agg_optimized.rs"]
mod agg_optimized;

#[cfg(test)]
#[path = "tests/aggregate_compatibility.rs"]
mod aggregate_compatibility;

#[cfg(test)]
#[path = "tests/aggregate_hotloop.rs"]
mod aggregate_hotloop;
