// Copyright 2026 The Roc Contributors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

pub(crate) mod group_index;

use super::{SinkExec, SourceExec};
use crate::arrow::datatypes::SchemaRef;
use crate::arrow::{
    array::ArrayRef,
    record_batch::{RecordBatch, RecordBatchOptions},
};
use crate::column::ColumnContext;
use crate::expr::agg::accumulator::Accumulator;
use crate::kernel::{LocalState, StateId};
use crate::operator::Operator;
use crate::{
    error::{Error, Result},
    operator::AggregateOperator,
};
use asyncband::shutdown::ShutdownGuard;
use futures::future::BoxFuture;
use group_index::GroupIndex;
use std::sync::{Arc, OnceLock};

// Bound merge work between cancellation checks and share output morsels among
// workers. The pipeline applies its own configured batch size to each morsel.
const AGGREGATE_MORSEL_ROWS: usize = 2048;

/// Only the pipeline coordinator merges local partials. No expression evaluator
/// or executable query plan is needed here: all inputs are accumulator states.
struct AggregateMergeState {
    index: GroupIndex,
    group_ids: Vec<usize>,
    output_schema: SchemaRef,
    accumulators: Vec<Accumulator>,
}

/// Each aggregate keeps its own state arrays; there is no flattened
/// partial schema or column-offset mapping between aggregates.
struct PartialAggregate {
    groups: RecordBatch,
    states: Vec<Vec<ArrayRef>>,
}

impl PartialAggregate {
    fn num_rows(&self) -> usize {
        self.groups.num_rows()
    }

    fn slice(&self, offset: usize, len: usize) -> Self {
        Self {
            groups: self.groups.slice(offset, len),
            states: self
                .states
                .iter()
                .map(|state| state.iter().map(|array| array.slice(offset, len)).collect())
                .collect(),
        }
    }
}

impl AggregateMergeState {
    fn new(operator: &AggregateOperator, columns: &ColumnContext) -> Result<Self> {
        let schema = columns.schema(&operator.group_columns())?;
        let mut accumulators = Vec::new();
        for aggregate in operator.aggregates() {
            let mut accumulator = aggregate.accumulator(columns)?;
            if schema.fields().is_empty() {
                accumulator.resize(1);
            }
            accumulators.push(accumulator);
        }
        Ok(Self {
            index: GroupIndex::new(&schema)?,
            group_ids: vec![],
            output_schema: columns.schema(&operator.output_columns())?,
            accumulators,
        })
    }
    fn merge(&mut self, partial: &PartialAggregate) -> Result<()> {
        // Each accumulator owns its partial-state schema. Check the complete
        // bundle before mutating any global group or accumulator state.
        if partial.states.len() != self.accumulators.len()
            || self
                .accumulators
                .iter()
                .zip(&partial.states)
                .any(|(a, columns)| {
                    let types = a.state_types();
                    types.len() != columns.len()
                        || types.iter().zip(columns).any(|(ty, column)| {
                            column.data_type() != ty || column.len() != partial.num_rows()
                        })
                })
        {
            return Err(Error::Execution("invalid aggregate partial state".into()));
        }
        if partial.num_rows() == 0 {
            return Ok(());
        }
        self.index.intern(
            partial.groups.columns(),
            partial.num_rows(),
            &mut self.group_ids,
        )?;
        for (accumulator, state) in self.accumulators.iter_mut().zip(&partial.states) {
            accumulator.resize(self.index.len());
            accumulator.merge(state, &self.group_ids)?;
        }
        Ok(())
    }
    fn finish(self) -> Result<RecordBatch> {
        let count = self.index.len();
        let mut columns = self.index.columns()?;
        for accumulator in self.accumulators {
            columns.push(accumulator.evaluate()?);
        }
        Ok(RecordBatch::try_new_with_options(
            self.output_schema,
            columns,
            &RecordBatchOptions::new().with_row_count(Some(count)),
        )?)
    }
}

#[derive(Debug, Default)]
struct AggregateSharedState {
    finalized: OnceLock<RecordBatch>,
}

/// Created for one execution. Only the result cell is shared across pipelines.
pub struct AggregateExecuteState {
    merge: AggregateMergeState,
    result: Arc<AggregateSharedState>,
}

pub struct AggregateSinkExec {
    states: Vec<StateId>,
    merge: Option<AggregateMergeState>,
    result: Arc<AggregateSharedState>,
}
pub struct AggregateSourceExec {
    result: Arc<AggregateSharedState>,
    next_row: usize,
}
impl AggregateOperator {
    pub fn new_execute_state(&self, columns: &ColumnContext) -> Result<AggregateExecuteState> {
        Ok(AggregateExecuteState {
            merge: AggregateMergeState::new(self, columns)?,
            result: Arc::new(AggregateSharedState::default()),
        })
    }
    pub fn build_exec(
        &self,
        state: AggregateExecuteState,
        locals: Vec<StateId>,
    ) -> (AggregateSourceExec, AggregateSinkExec) {
        let source = AggregateSourceExec {
            result: state.result.clone(),
            next_row: 0,
        };
        let sink = AggregateSinkExec {
            states: locals,
            merge: Some(state.merge),
            result: state.result,
        };
        (source, sink)
    }
}

impl SinkExec for AggregateSinkExec {
    fn combine<'a>(
        &'a mut self,
        mut local: LocalState,
        guard: &'a ShutdownGuard,
    ) -> BoxFuture<'a, Result<()>> {
        Box::pin(async move {
            let (groups, states) = crate::kernel::aggregation::partial(&mut local, &self.states)?;
            let partial = PartialAggregate { groups, states };
            let merge = self
                .merge
                .as_mut()
                .ok_or_else(|| Error::Execution("aggregate already finished".into()))?;
            for offset in (0..partial.num_rows()).step_by(AGGREGATE_MORSEL_ROWS) {
                if guard.is_shutdown_requested() {
                    return Err(Error::Cancelled);
                }
                merge.merge(&partial.slice(
                    offset,
                    AGGREGATE_MORSEL_ROWS.min(partial.num_rows() - offset),
                ))?;
                crate::pipeline::yield_now().await;
            }
            Ok(())
        })
    }
    fn finish<'a>(&'a mut self, guard: &'a ShutdownGuard) -> BoxFuture<'a, Result<()>> {
        Box::pin(async move {
            if guard.is_shutdown_requested() {
                return Err(Error::Cancelled);
            }
            let batch = self
                .merge
                .take()
                .ok_or_else(|| Error::Execution("aggregate already finished".into()))?
                .finish()?;
            self.result
                .finalized
                .set(batch)
                .map_err(|_| Error::Execution("aggregate result already published".into()))
        })
    }
}
impl SourceExec for AggregateSourceExec {
    fn start(&mut self, _: &ShutdownGuard) -> Result<()> {
        if self.result.finalized.get().is_none() {
            return Err(Error::Execution(
                "aggregate source started before sink finished".into(),
            ));
        }
        Ok(())
    }
    fn next_batch<'a>(
        &'a mut self,
        guard: &'a ShutdownGuard,
    ) -> BoxFuture<'a, Result<Option<RecordBatch>>> {
        Box::pin(async move {
            if guard.is_shutdown_requested() {
                return Err(Error::Cancelled);
            }
            let batch = self
                .result
                .finalized
                .get()
                .ok_or_else(|| Error::Execution("aggregate result is not ready".into()))?;
            if self.next_row >= batch.num_rows() {
                return Ok(None);
            }
            let rows = AGGREGATE_MORSEL_ROWS.min(batch.num_rows() - self.next_row);
            let output = batch.slice(self.next_row, rows);
            self.next_row += rows;
            Ok(Some(output))
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::arrow::{
        array::{Array, Float64Array, Int64Array, StringArray},
        datatypes::DataType,
    };
    use crate::column::ColumnId;
    use crate::expr::{
        agg::{AggregateExpression, AggregateFunction},
        scalar::{
            ConstantExpression, FunctionExpression, FunctionKind, ReferenceExpression,
            ScalarExprRef, test_support::TestPlan,
        },
    };
    use crate::kernel::{ExecutionMode, KernelBuilder, MODES, Program, agree};
    use asyncband::shutdown::Shutdown;

    /// One worker per execution mode: the aggregate's input program and its
    /// local state, plus a merge state standing in for the sink. Every input
    /// goes to all workers; their results must agree.
    struct AggregateState {
        workers: Vec<(ExecutionMode, Program, LocalState, AggregateMergeState)>,
        states: Vec<StateId>,
        _shutdown: Shutdown,
        guard: ShutdownGuard,
    }

    /// DISTINCT states list hash set members in unspecified order.
    fn same_partial(a: &PartialAggregate, b: &PartialAggregate) -> bool {
        use crate::arrow::array::AsArray;
        let members = |array: &ArrayRef| {
            let list = array.as_list::<i32>();
            (0..list.len())
                .map(|i| {
                    let mut values = (0..list.value(i).len())
                        .map(|j| list.value(i).as_binary::<i32>().value(j).to_vec())
                        .collect::<Vec<_>>();
                    values.sort();
                    values
                })
                .collect::<Vec<_>>()
        };
        let same = |x: &ArrayRef, y: &ArrayRef| match x.data_type() {
            DataType::List(_) => x.data_type() == y.data_type() && members(x) == members(y),
            _ => x == y,
        };
        a.groups == b.groups
            && a.states.len() == b.states.len()
            && a.states
                .iter()
                .zip(&b.states)
                .all(|(x, y)| x.len() == y.len() && x.iter().zip(y).all(|(x, y)| same(x, y)))
    }

    impl AggregateState {
        fn new(plan: &TestPlan, operator: &AggregateOperator) -> Result<Self> {
            let mut workers = vec![];
            let mut states = vec![];
            for mode in MODES {
                let merged = AggregateMergeState::new(operator, &plan.columns)?;
                let mut builder = KernelBuilder::new(&plan.columns);
                builder.bind_inputs(&plan.inputs)?;
                states = operator.build_kernels(&mut builder)?;
                let program = Program::new(builder.finish(None)?, mode)?;
                let local = program.new_local()?;
                workers.push((mode, program, local, merged));
            }
            let (shutdown, guard) = asyncband::shutdown::new();
            Ok(Self {
                workers,
                states,
                _shutdown: shutdown,
                guard,
            })
        }
        fn update(&mut self, batch: &RecordBatch) -> Result<()> {
            let results = self
                .workers
                .iter_mut()
                .map(|(mode, program, local, _)| {
                    (*mode, program.run(batch, local, &self.guard).map(|_| ()))
                })
                .collect();
            agree(results, |_, _| true)
        }
        fn finish_partial(mut self) -> Result<PartialAggregate> {
            let results = self
                .workers
                .iter_mut()
                .map(|(mode, _, local, _)| {
                    let partial = crate::kernel::aggregation::partial(local, &self.states)
                        .map(|(groups, states)| PartialAggregate { groups, states });
                    (*mode, partial)
                })
                .collect();
            agree(results, same_partial)
        }
        fn merge(&mut self, partial: &PartialAggregate) -> Result<()> {
            let results = self
                .workers
                .iter_mut()
                .map(|(mode, _, _, merged)| (*mode, merged.merge(partial)))
                .collect();
            agree(results, |_, _| true)
        }
        fn finish(self) -> Result<RecordBatch> {
            let states = self.states;
            let results = self
                .workers
                .into_iter()
                .map(|(mode, _, mut local, mut merged)| {
                    let result = (|| {
                        let (groups, states) =
                            crate::kernel::aggregation::partial(&mut local, &states)?;
                        merged.merge(&PartialAggregate { groups, states })?;
                        merged.finish()
                    })();
                    (mode, result)
                })
                .collect();
            agree(results, |a, b| a == b)
        }
    }

    /// Input columns `key: Utf8?` and `value: Float64?`.
    fn plan() -> TestPlan {
        TestPlan::new(&[(DataType::Utf8, true), (DataType::Float64, true)])
    }
    fn value(plan: &TestPlan) -> ScalarExprRef {
        ReferenceExpression::new(plan.input(1)).into_ref()
    }
    fn groups(plan: &TestPlan, grouped: bool) -> Vec<ScalarExprRef> {
        if grouped {
            vec![ReferenceExpression::new(plan.input(0)).into_ref()]
        } else {
            vec![]
        }
    }
    fn aggregate(
        plan: &mut TestPlan,
        function: AggregateFunction,
        arguments: Vec<ScalarExprRef>,
        data_type: DataType,
        nullable: bool,
    ) -> AggregateExpression {
        let output = plan.column(data_type, nullable);
        AggregateExpression::new(function, arguments, output)
    }
    /// Result types and nullability are host-supplied: SUM over Float64 is
    /// Float64, AVG and COVAR_POP are Float64, and only COUNT is non-nullable.
    fn aggregates(plan: &mut TestPlan) -> Vec<Arc<AggregateExpression>> {
        use AggregateFunction::*;
        let v = value(plan);
        vec![
            Arc::new(aggregate(
                plan,
                Sum,
                vec![v.clone()],
                DataType::Float64,
                true,
            )),
            Arc::new(aggregate(
                plan,
                Avg,
                vec![v.clone()],
                DataType::Float64,
                true,
            )),
            Arc::new(aggregate(
                plan,
                Count,
                vec![v.clone()],
                DataType::Int64,
                false,
            )),
            Arc::new(
                aggregate(plan, Count, vec![v.clone()], DataType::Int64, false).with_distinct(),
            ),
            Arc::new(aggregate(
                plan,
                CovarPop,
                vec![v.clone(), v],
                DataType::Float64,
                true,
            )),
            Arc::new(aggregate(plan, Count, vec![], DataType::Int64, false)),
        ]
    }
    fn input(plan: &TestPlan, columns: Vec<ArrayRef>) -> RecordBatch {
        RecordBatch::try_new(plan.columns.schema(&plan.inputs).unwrap(), columns).unwrap()
    }
    fn batch(plan: &TestPlan, keys: Vec<Option<&str>>, values: Vec<Option<f64>>) -> RecordBatch {
        input(
            plan,
            vec![
                Arc::new(StringArray::from(keys)),
                Arc::new(Float64Array::from(values)),
            ],
        )
    }
    fn empty(plan: &TestPlan) -> RecordBatch {
        RecordBatch::new_empty(plan.columns.schema(&plan.inputs).unwrap())
    }
    fn int(plan: &mut TestPlan, v: i64) -> ScalarExprRef {
        let output = plan.column(DataType::Int64, false);
        ConstantExpression::int64(Some(v), output).into_ref()
    }
    fn output_schema(plan: &TestPlan, operator: &AggregateOperator) -> SchemaRef {
        plan.columns.schema(&operator.output_columns()).unwrap()
    }
    fn group_schema(plan: &TestPlan, operator: &AggregateOperator) -> SchemaRef {
        let columns: Vec<ColumnId> = operator.group_columns();
        plan.columns.schema(&columns).unwrap()
    }

    #[test]
    fn generated_global_reductions_handle_sliced_bitmaps_arbitrary_null_payloads_and_tails() {
        use crate::arrow::buffer::NullBuffer;
        use crate::expr::agg::AggregateFunction::{Count, Sum};
        let mut plan = TestPlan::new(&[(DataType::Int64, true)]);
        let reference = ReferenceExpression::new(plan.input(0)).into_ref();
        let sum = aggregate(
            &mut plan,
            Sum,
            vec![reference.clone()],
            DataType::Int64,
            true,
        );
        let count = aggregate(&mut plan, Count, vec![reference], DataType::Int64, false);
        let operator =
            AggregateOperator::try_new(vec![], vec![Arc::new(sum), Arc::new(count)]).unwrap();
        for pattern in [0, 1, 2, 17] {
            for offset in [0, 1, 7, 9] {
                let values = (0..150)
                    .map(|i| if i % 3 == 0 { i64::MAX } else { -(i as i64) })
                    .collect::<Vec<_>>();
                let valid = (0..150)
                    .map(|i| pattern == 0 || (pattern != 1 && i % pattern != 0))
                    .collect::<Vec<_>>();
                let values = Int64Array::new(values.into(), Some(NullBuffer::from(valid)))
                    .slice(offset, 140);
                for len in [0, 1, 7, 8, 63, 64, 65, 127, 129] {
                    let values = values.slice(0, len);
                    let expected = values.iter().flatten().fold(0i64, i64::wrapping_add);
                    let count = values.len() - values.null_count();
                    let batch = input(&plan, vec![Arc::new(values)]);
                    let mut state = AggregateState::new(&plan, &operator).unwrap();
                    state.update(&batch).unwrap();
                    // Repeated calls also exercise persisted state and wrapping merges.
                    state.update(&batch).unwrap();
                    let out = state.finish().unwrap();
                    let sum = out.column(0).as_any().downcast_ref::<Int64Array>().unwrap();
                    let actual_count = out.column(1).as_any().downcast_ref::<Int64Array>().unwrap();
                    assert_eq!(sum.is_null(0), count == 0);
                    if count != 0 {
                        assert_eq!(sum.value(0), expected.wrapping_mul(2));
                    }
                    assert_eq!(actual_count.value(0), 2 * count as i64);
                }
            }
        }
    }

    #[test]
    fn merges_distinct_and_multi_column_states_across_workers() {
        let mut plan = plan();
        let aggregates = aggregates(&mut plan);
        let operator = AggregateOperator::try_new(groups(&plan, true), aggregates).unwrap();
        let batches = [
            batch(
                &plan,
                vec![Some("a"), None, Some("a"), Some("b")],
                vec![Some(1.), Some(2.), Some(3.), None],
            ),
            batch(
                &plan,
                vec![Some("b"), Some("a"), None],
                vec![Some(8.), Some(3.), Some(4.)],
            ),
        ];
        let mut merged = AggregateState::new(&plan, &operator).unwrap();
        for batch in batches {
            let mut worker = AggregateState::new(&plan, &operator).unwrap();
            // Exercise repeated updates and one-row partial merge chunks.
            for row in 0..batch.num_rows() {
                worker.update(&batch.slice(row, 1)).unwrap();
            }
            let partial = worker.finish_partial().unwrap();
            assert_eq!(partial.groups.schema(), group_schema(&plan, &operator));
            for row in 0..partial.num_rows() {
                merged.merge(&partial.slice(row, 1)).unwrap();
            }
        }
        let result = merged.finish().unwrap();
        assert_eq!(result.schema(), output_schema(&plan, &operator));
        assert_eq!(result.num_rows(), 3);
        let keys = result
            .column(0)
            .as_any()
            .downcast_ref::<StringArray>()
            .unwrap();
        for row in 0..3 {
            let (sum, avg, count, distinct, covar, rows) = if keys.is_null(row) {
                (6., 3., 2, 2, 1., 2)
            } else if keys.value(row) == "a" {
                (7., 7. / 3., 3, 2, 8. / 9., 3)
            } else {
                assert_eq!(keys.value(row), "b");
                (8., 8., 1, 1, 0., 2)
            };
            for (column, expected) in [(1, sum), (2, avg), (5, covar)] {
                let array = result
                    .column(column)
                    .as_any()
                    .downcast_ref::<Float64Array>()
                    .unwrap();
                assert!(array.is_valid(row));
                assert!((array.value(row) - expected).abs() < 1e-10);
            }
            for (column, expected) in [(3, count), (4, distinct), (6, rows)] {
                let array = result
                    .column(column)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap();
                assert_eq!(array.value(row), expected);
            }
        }
    }

    #[test]
    fn empty_global_input_has_one_row() {
        let mut plan = plan();
        let aggregates = aggregates(&mut plan);
        let operator = AggregateOperator::try_new(vec![], aggregates).unwrap();
        let mut merged = AggregateState::new(&plan, &operator).unwrap();
        for update_empty in [false, true] {
            let mut worker = AggregateState::new(&plan, &operator).unwrap();
            if update_empty {
                worker.update(&empty(&plan)).unwrap();
            }
            merged.merge(&worker.finish_partial().unwrap()).unwrap();
        }
        for result in [
            merged.finish().unwrap(),
            AggregateState::new(&plan, &operator)
                .unwrap()
                .finish()
                .unwrap(),
        ] {
            assert_eq!(result.num_rows(), 1);
            for col in [0, 1, 4] {
                assert!(
                    result.column(col).is_null(0),
                    "column {col}: {:?}",
                    result.column(col)
                );
            }
            for col in [2, 3, 5] {
                assert_eq!(
                    result
                        .column(col)
                        .as_any()
                        .downcast_ref::<Int64Array>()
                        .unwrap()
                        .value(0),
                    0
                );
            }
        }
    }

    #[test]
    fn all_null_group_stays_null_across_empty_batches_and_merges() {
        let mut plan = plan();
        let aggregates = aggregates(&mut plan);
        let operator = AggregateOperator::try_new(groups(&plan, true), aggregates).unwrap();
        let mut worker = AggregateState::new(&plan, &operator).unwrap();
        worker
            .update(&batch(&plan, vec![Some("a"); 2], vec![None; 2]))
            .unwrap();
        worker.update(&empty(&plan)).unwrap();
        let mut merged = AggregateState::new(&plan, &operator).unwrap();
        merged.merge(&worker.finish_partial().unwrap()).unwrap();
        merged
            .merge(
                &AggregateState::new(&plan, &operator)
                    .unwrap()
                    .finish_partial()
                    .unwrap(),
            )
            .unwrap();
        let result = merged.finish().unwrap();
        assert_eq!(result.num_rows(), 1);
        for col in [1, 2, 5] {
            assert!(result.column(col).is_null(0));
        }
        for (col, expected) in [(3, 0), (4, 0), (6, 2)] {
            assert_eq!(
                result
                    .column(col)
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .value(0),
                expected
            );
        }
    }

    #[test]
    fn global_input_merges_distinct_and_multi_column_states() {
        let mut plan = plan();
        let aggregates = aggregates(&mut plan);
        let operator = AggregateOperator::try_new(vec![], aggregates).unwrap();
        let mut merged = AggregateState::new(&plan, &operator).unwrap();
        for values in [vec![Some(2.), None], vec![Some(2.), Some(4.)]] {
            let mut worker = AggregateState::new(&plan, &operator).unwrap();
            worker
                .update(&batch(&plan, vec![None; values.len()], values))
                .unwrap();
            merged.merge(&worker.finish_partial().unwrap()).unwrap();
        }
        let result = merged.finish().unwrap();
        assert_eq!(result.num_rows(), 1);
        assert_eq!(
            result
                .column(0)
                .as_any()
                .downcast_ref::<Float64Array>()
                .unwrap()
                .value(0),
            8.
        );
        assert_eq!(
            result
                .column(3)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap()
                .value(0),
            2
        );
        assert_eq!(
            result
                .column(5)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap()
                .value(0),
            4
        );
    }

    #[test]
    fn empty_grouped_input_and_grouping_without_aggregates() {
        let mut plan = plan();
        for aggregates in [aggregates(&mut plan), vec![]] {
            let operator = AggregateOperator::try_new(groups(&plan, true), aggregates).unwrap();
            let mut state = AggregateState::new(&plan, &operator).unwrap();
            state.update(&empty(&plan)).unwrap();
            let partial = state.finish_partial().unwrap();
            assert_eq!(partial.num_rows(), 0);
            assert_eq!(partial.groups.schema(), group_schema(&plan, &operator));
            for (arrays, aggregate) in partial.states.iter().zip(operator.aggregates()) {
                let fields = aggregate.accumulator(&plan.columns).unwrap().state_types();
                assert_eq!(arrays.len(), fields.len());
                for (array, field) in arrays.iter().zip(fields) {
                    assert_eq!(array.len(), 0);
                    assert_eq!(array.data_type(), &field);
                }
            }
            let mut merged = AggregateState::new(&plan, &operator).unwrap();
            merged.merge(&partial).unwrap();
            let result = merged.finish().unwrap();
            assert_eq!(result.num_rows(), 0);
            assert_eq!(result.schema(), output_schema(&plan, &operator));
        }

        let operator = AggregateOperator::try_new(groups(&plan, true), vec![]).unwrap();
        let mut worker = AggregateState::new(&plan, &operator).unwrap();
        worker
            .update(&batch(
                &plan,
                vec![Some("a"), None, Some("a")],
                vec![None; 3],
            ))
            .unwrap();
        let mut merged = AggregateState::new(&plan, &operator).unwrap();
        merged.merge(&worker.finish_partial().unwrap()).unwrap();
        let result = merged.finish().unwrap();
        assert_eq!((result.num_rows(), result.num_columns()), (2, 1));
        assert_eq!(result.column(0).null_count(), 1);
    }

    #[test]
    fn rejects_empty_specification() {
        assert!(AggregateOperator::try_new(vec![], vec![]).is_err());
    }

    #[test]
    fn aggregate_filter_runs_before_arguments_and_preserves_empty_groups() {
        let mut plan = TestPlan::new(&[(DataType::Utf8, false), (DataType::Int64, false)]);
        let value = ReferenceExpression::new(plan.input(1)).into_ref();
        let zero = int(&mut plan, 0);
        let hundred = int(&mut plan, 100);
        let ne = plan.column(DataType::Boolean, false);
        let predicate =
            FunctionExpression::binary(FunctionKind::NotEqual, value.clone(), zero, ne).into_ref();
        let quotient = plan.column(DataType::Int64, true);
        let division =
            FunctionExpression::binary(FunctionKind::Divide, hundred, value.clone(), quotient)
                .into_ref();
        let sum = aggregate(
            &mut plan,
            AggregateFunction::Sum,
            vec![division],
            DataType::Int64,
            true,
        )
        .with_filter(predicate.clone());
        let distinct = aggregate(
            &mut plan,
            AggregateFunction::Count,
            vec![value],
            DataType::Int64,
            false,
        )
        .with_distinct()
        .with_filter(predicate);
        let operator = AggregateOperator::try_new(
            vec![ReferenceExpression::new(plan.input(0)).into_ref()],
            vec![Arc::new(sum), Arc::new(distinct)],
        )
        .unwrap();
        let mut merged = AggregateState::new(&plan, &operator).unwrap();
        for _ in 0..2 {
            let input = input(
                &plan,
                vec![
                    Arc::new(StringArray::from(vec!["a", "b", "a"])),
                    Arc::new(Int64Array::from(vec![2, 0, 4])),
                ],
            );
            let mut worker = AggregateState::new(&plan, &operator).unwrap();
            worker.update(&input).unwrap();
            merged.merge(&worker.finish_partial().unwrap()).unwrap();
        }
        let result = merged.finish().unwrap();
        assert_eq!(
            result
                .column(1)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap()
                .iter()
                .collect::<Vec<_>>(),
            vec![Some(150), None]
        );
        assert_eq!(
            result
                .column(2)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap()
                .values()
                .as_ref(),
            &[2, 0]
        );
    }

    #[test]
    fn extrema_merge_values_and_keep_string_null_semantics() {
        let mut plan = TestPlan::new(&[(DataType::Utf8, true)]);
        let expr = ReferenceExpression::new(plan.input(0)).into_ref();
        let aggregates = [AggregateFunction::Min, AggregateFunction::Max]
            .into_iter()
            .map(|f| {
                Arc::new(aggregate(
                    &mut plan,
                    f,
                    vec![expr.clone()],
                    DataType::Utf8,
                    true,
                ))
            })
            .collect();
        let operator = AggregateOperator::try_new(vec![], aggregates).unwrap();
        let mut merged = AggregateState::new(&plan, &operator).unwrap();
        for values in [vec![Some("z"), None], vec![None, Some("a")], vec![None]] {
            let input = input(&plan, vec![Arc::new(StringArray::from(values))]);
            let mut worker = AggregateState::new(&plan, &operator).unwrap();
            worker.update(&input).unwrap();
            merged.merge(&worker.finish_partial().unwrap()).unwrap();
        }
        let result = merged.finish().unwrap();
        assert_eq!(
            result
                .column(0)
                .as_any()
                .downcast_ref::<StringArray>()
                .unwrap()
                .value(0),
            "a"
        );
        assert_eq!(
            result
                .column(1)
                .as_any()
                .downcast_ref::<StringArray>()
                .unwrap()
                .value(0),
            "z"
        );
        let empty = AggregateState::new(&plan, &operator)
            .unwrap()
            .finish()
            .unwrap();
        assert!(empty.column(0).is_null(0));
        assert!(empty.column(1).is_null(0));
    }

    #[test]
    fn integer_sum_stays_exact_and_wraps_on_update_and_partial_merge() {
        use crate::arrow::array::UInt64Array;
        for (array, expected) in [
            (
                Arc::new(UInt64Array::from(vec![
                    Some(9_007_199_254_740_993),
                    None,
                    Some(2),
                ])) as ArrayRef,
                Arc::new(UInt64Array::from(vec![9_007_199_254_740_995])) as ArrayRef,
            ),
            (
                Arc::new(Int64Array::from(vec![Some(i64::MAX), None, Some(1)])) as ArrayRef,
                Arc::new(Int64Array::from(vec![i64::MIN])) as ArrayRef,
            ),
            (
                Arc::new(Int64Array::from(vec![Some(i64::MIN), None, Some(-1)])) as ArrayRef,
                Arc::new(Int64Array::from(vec![i64::MAX])) as ArrayRef,
            ),
            (
                Arc::new(UInt64Array::from(vec![Some(u64::MAX), None, Some(1)])) as ArrayRef,
                Arc::new(UInt64Array::from(vec![0])) as ArrayRef,
            ),
        ] {
            let data_type = array.data_type().clone();
            let mut plan = TestPlan::new(&[(data_type.clone(), true)]);
            let reference = ReferenceExpression::new(plan.input(0)).into_ref();
            let sum = aggregate(
                &mut plan,
                AggregateFunction::Sum,
                vec![reference],
                data_type.clone(),
                true,
            );
            let operator = AggregateOperator::try_new(vec![], vec![Arc::new(sum)]).unwrap();
            let mut state = AggregateState::new(&plan, &operator).unwrap();
            let input = input(&plan, vec![array]);
            state.update(&input).unwrap();

            // Each worker's value fits by itself; overflow occurs only when
            // partial states combine. Include a NULL-only worker as well.
            let mut merged = AggregateState::new(&plan, &operator).unwrap();
            for row in 0..input.num_rows() {
                let mut worker = AggregateState::new(&plan, &operator).unwrap();
                worker.update(&input.slice(row, 1)).unwrap();
                merged.merge(&worker.finish_partial().unwrap()).unwrap();
            }
            for result in [state.finish().unwrap(), merged.finish().unwrap()] {
                assert_eq!(
                    result.column(0).to_data(),
                    expected.to_data(),
                    "SUM over {data_type}"
                );
            }
        }
    }

    #[test]
    fn filtered_count_star_handles_zero_column_batches() {
        let mut plan = TestPlan::new(&[]);
        let expressions = [true, false]
            .into_iter()
            .map(|v| {
                let predicate = plan.column(DataType::Boolean, false);
                let filter = ConstantExpression::boolean(Some(v), predicate).into_ref();
                Arc::new(
                    aggregate(
                        &mut plan,
                        AggregateFunction::Count,
                        vec![],
                        DataType::Int64,
                        false,
                    )
                    .with_filter(filter),
                )
            })
            .collect();
        let operator = AggregateOperator::try_new(vec![], expressions).unwrap();
        let mut state = AggregateState::new(&plan, &operator).unwrap();
        let batch = RecordBatch::try_new_with_options(
            plan.columns.schema(&[]).unwrap(),
            vec![],
            &RecordBatchOptions::new().with_row_count(Some(3)),
        )
        .unwrap();
        state.update(&batch).unwrap();
        let result = state.finish().unwrap();
        assert_eq!(
            result
                .column(0)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap()
                .value(0),
            3
        );
        assert_eq!(
            result
                .column(1)
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap()
                .value(0),
            0
        );
    }

    #[test]
    fn aggregate_signatures_without_usable_kernels_are_plan_errors() {
        // DISTINCT and MIN/MAX derive their state key type from an argument, so
        // a missing argument has no kernel to build. The operator itself only
        // assembles descriptions; building its kernels is the first point that
        // builds an accumulator.
        use AggregateFunction::*;
        let mut plan = plan();
        let v = value(&plan);
        for expr in [
            aggregate(&mut plan, Count, vec![], DataType::Int64, false).with_distinct(),
            aggregate(&mut plan, Min, vec![], DataType::Utf8, true),
            aggregate(&mut plan, Max, vec![], DataType::Utf8, true),
            // Only COUNT keeps a DISTINCT set; the others would silently drop it.
            aggregate(&mut plan, Sum, vec![v.clone()], DataType::Float64, true).with_distinct(),
        ] {
            let operator = AggregateOperator::try_new(vec![], vec![Arc::new(expr)])
                .expect("operator construction does not validate aggregates");
            assert!(matches!(
                AggregateState::new(&plan, &operator),
                Err(Error::InvalidPlan(_))
            ));
        }
    }

    #[test]
    fn aggregate_signatures_are_checked_before_code_generation() {
        use AggregateFunction::*;
        let mut plan = plan();
        let v = value(&plan);
        for expr in [
            aggregate(
                &mut plan,
                Count,
                vec![v.clone(), v.clone()],
                DataType::Int64,
                false,
            ),
            aggregate(&mut plan, Sum, vec![], DataType::Float64, true),
            aggregate(&mut plan, Avg, vec![], DataType::Float64, true),
            aggregate(
                &mut plan,
                CovarPop,
                vec![v.clone()],
                DataType::Float64,
                true,
            ),
            aggregate(&mut plan, Min, vec![v.clone()], DataType::Utf8, true),
            aggregate(&mut plan, Count, vec![], DataType::Float64, false),
        ] {
            let operator = AggregateOperator::try_new(vec![], vec![Arc::new(expr)]).unwrap();
            assert!(matches!(
                AggregateState::new(&plan, &operator),
                Err(Error::InvalidPlan(_))
            ));
        }

        // SUM inserts a TRY cast; unparseable text becomes NULL.
        let text = plan.column(DataType::Utf8, false);
        let text = ConstantExpression::string(Some("x"), text).into_ref();
        let sum = aggregate(&mut plan, Sum, vec![text], DataType::Int64, true);
        let operator = AggregateOperator::try_new(vec![], vec![Arc::new(sum)]).unwrap();
        let mut state = AggregateState::new(&plan, &operator).unwrap();
        state
            .update(&batch(&plan, vec![Some("a")], vec![Some(1.)]))
            .expect("an unparseable value is skipped, not rejected");
        assert!(state.finish().unwrap().column(0).is_null(0));

        // A filter must evaluate to Boolean before rows can be selected.
        let rows = aggregate(&mut plan, Count, vec![], DataType::Int64, false).with_filter(v);
        let operator = AggregateOperator::try_new(vec![], vec![Arc::new(rows)]).unwrap();
        assert!(matches!(
            AggregateState::new(&plan, &operator),
            Err(Error::InvalidPlan(_))
        ));
    }

    #[test]
    fn unsupported_sum_result_type_is_rejected_before_codegen() {
        // The host declares the SUM result type; an unusable one must not panic.
        let mut plan = plan();
        let v = value(&plan);
        let sum = aggregate(
            &mut plan,
            AggregateFunction::Sum,
            vec![v],
            DataType::Utf8,
            true,
        );
        let operator = AggregateOperator::try_new(vec![], vec![Arc::new(sum)]).unwrap();
        assert!(matches!(
            AggregateState::new(&plan, &operator),
            Err(Error::InvalidPlan(_))
        ));
    }

    #[test]
    fn integer_groups_remap_partial_ids_and_keep_null_and_wrapping_sum() {
        use std::collections::BTreeMap;
        let mut plan = TestPlan::new(&[(DataType::Int64, true), (DataType::Int64, true)]);
        let value = ReferenceExpression::new(plan.input(1)).into_ref();
        let sum = aggregate(
            &mut plan,
            AggregateFunction::Sum,
            vec![value.clone()],
            DataType::Int64,
            true,
        );
        let count = aggregate(
            &mut plan,
            AggregateFunction::Count,
            vec![value],
            DataType::Int64,
            false,
        );
        let operator = AggregateOperator::try_new(
            vec![ReferenceExpression::new(plan.input(0)).into_ref()],
            vec![Arc::new(sum), Arc::new(count)],
        )
        .unwrap();
        let inputs = [
            (
                vec![Some(i64::MIN), None, Some(0), Some(i64::MAX)],
                vec![Some(i64::MAX), None, Some(2), Some(4)],
            ),
            (
                vec![Some(i64::MAX), Some(i64::MIN), None, Some(1)],
                vec![Some(3), Some(1), None, Some(-1)],
            ),
        ];
        let mut merged = AggregateState::new(&plan, &operator).unwrap();
        for (keys, values) in inputs {
            let input = input(
                &plan,
                vec![
                    Arc::new(Int64Array::from(keys)),
                    Arc::new(Int64Array::from(values)),
                ],
            );
            let mut partial = AggregateState::new(&plan, &operator).unwrap();
            partial.update(&input).unwrap();
            merged.merge(&partial.finish_partial().unwrap()).unwrap();
        }
        let output = merged.finish().unwrap();
        let arrays = output
            .columns()
            .iter()
            .map(|a| a.as_any().downcast_ref::<Int64Array>().unwrap())
            .collect::<Vec<_>>();
        let actual = arrays[0]
            .iter()
            .zip(arrays[1].iter().zip(arrays[2].iter()))
            .collect::<BTreeMap<_, _>>();
        assert_eq!(
            actual,
            BTreeMap::from([
                (None, (None, Some(0))),
                (Some(i64::MIN), (Some(i64::MIN), Some(2))),
                (Some(0), (Some(2), Some(1))),
                (Some(1), (Some(-1), Some(1))),
                (Some(i64::MAX), (Some(7), Some(2))),
            ])
        );
    }
}
