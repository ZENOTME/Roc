// Copyright 2026 The Roc Contributors
// SPDX-License-Identifier: Apache-2.0

use std::sync::Arc;

use crate::arrow::{
    array::{Array, ArrayRef, BooleanArray, Float64Array, Int64Array, UInt64Array},
    datatypes::{DataType, Field, Schema},
    record_batch::RecordBatch,
};
use crate::expr::{
    agg::{AggregateExpression, AggregateFunction, test_support::AccumulatorTestHarness},
    scalar::{
        ConstantExpression, FunctionExpression, FunctionKind, ReferenceExpression,
        test_support::TestPlan,
    },
};

fn batch(array: ArrayRef) -> RecordBatch {
    RecordBatch::try_new(
        Arc::new(Schema::new(vec![Field::new(
            "value",
            array.data_type().clone(),
            true,
        )])),
        vec![array],
    )
    .unwrap()
}

/// `function(value)` over one nullable input column.
fn expression(
    function: AggregateFunction,
    input: DataType,
    output: DataType,
) -> (TestPlan, AggregateExpression) {
    let mut plan = TestPlan::new(&[(input, true)]);
    let output = plan.column(output, true);
    let expression = AggregateExpression::new(
        function,
        vec![ReferenceExpression::new(plan.input(0)).into_ref()],
        output,
    );
    (plan, expression)
}

fn executor((plan, expression): (TestPlan, AggregateExpression)) -> AccumulatorTestHarness {
    AccumulatorTestHarness::try_new(&plan, Arc::new(expression)).unwrap()
}

#[test]
fn global_reduction_matches_grouped_path_across_batches_and_nulls() {
    let batches = [
        batch(Arc::new(Int64Array::from(vec![
            None,
            Some(4),
            Some(-4),
            None,
        ]))),
        batch(Arc::new(Int64Array::from(vec![Some(9), Some(9), None]))),
        batch(Arc::new(Int64Array::from(vec![None, None]))),
        batch(Arc::new(Int64Array::from(Vec::<Option<i64>>::new()))),
    ];
    for (function, output) in [
        (AggregateFunction::Count, DataType::Int64),
        (AggregateFunction::Sum, DataType::Int64),
        (AggregateFunction::Avg, DataType::Float64),
        (AggregateFunction::Min, DataType::Int64),
        (AggregateFunction::Max, DataType::Int64),
    ] {
        let expr = expression(function, DataType::Int64, output);
        let mut single = executor(expr.clone());
        let mut grouped = executor(expr);
        for batch in &batches {
            single.update_single(batch).unwrap();
            grouped
                .update(batch, &vec![0; batch.num_rows()], 1)
                .unwrap();
            assert_eq!(
                single.evaluate().unwrap().to_data(),
                grouped.evaluate().unwrap().to_data()
            );
            for (left, right) in single.state().unwrap().iter().zip(grouped.state().unwrap()) {
                assert_eq!(left.to_data(), right.to_data());
            }
        }
    }
    let (plan, count) = expression(AggregateFunction::Count, DataType::Int64, DataType::Int64);
    let mut distinct = executor((plan, count.with_distinct()));
    for batch in &batches {
        distinct.update_single(batch).unwrap();
    }
    assert_eq!(
        distinct
            .evaluate()
            .unwrap()
            .as_any()
            .downcast_ref::<Int64Array>()
            .unwrap()
            .value(0),
        3
    );
}

#[test]
fn global_integer_sums_wrap_within_and_between_batches() {
    for array in [
        Arc::new(Int64Array::from(vec![Some(i64::MAX), None, Some(1)])) as ArrayRef,
        Arc::new(UInt64Array::from(vec![Some(u64::MAX), None, Some(1)])),
    ] {
        let kind = array.data_type().clone();
        let mut single = executor(expression(AggregateFunction::Sum, kind.clone(), kind));
        single.update_single(&batch(array.clone())).unwrap();
        single.update_single(&batch(array)).unwrap();
        let output = single.evaluate().unwrap();
        match output.data_type() {
            DataType::Int64 => assert_eq!(
                output
                    .as_any()
                    .downcast_ref::<Int64Array>()
                    .unwrap()
                    .value(0),
                0
            ),
            DataType::UInt64 => assert_eq!(
                output
                    .as_any()
                    .downcast_ref::<UInt64Array>()
                    .unwrap()
                    .value(0),
                0
            ),
            _ => unreachable!(),
        }
    }
}

#[test]
fn global_empty_states_and_checked_counts_are_preserved() {
    let nulls = batch(Arc::new(Int64Array::from(vec![None, None])));
    let mut sum = executor(expression(
        AggregateFunction::Sum,
        DataType::Int64,
        DataType::Int64,
    ));
    sum.update_single(&nulls).unwrap();
    assert!(sum.evaluate().unwrap().is_null(0));
    let mut avg = executor(expression(
        AggregateFunction::Avg,
        DataType::Int64,
        DataType::Float64,
    ));
    avg.update_single(&nulls).unwrap();
    assert!(avg.evaluate().unwrap().is_null(0));
    assert!(avg.state().unwrap().iter().all(|state| state.is_null(0)));
    let mut count = executor(expression(
        AggregateFunction::Count,
        DataType::Int64,
        DataType::Int64,
    ));
    count
        .merge(&[Arc::new(Int64Array::from(vec![i64::MAX]))], &[0], 1)
        .unwrap();
    count.update_single(&nulls).unwrap();
    assert!(
        count
            .update_single(&batch(Arc::new(Int64Array::from(vec![1]))))
            .is_err()
    );
    let mut plan = TestPlan::new(&[(DataType::Int64, true)]);
    let output = plan.column(DataType::Int64, false);
    let mut count_star = executor((
        plan,
        AggregateExpression::new(AggregateFunction::Count, vec![], output),
    ));
    count_star.update_single(&nulls).unwrap();
    assert_eq!(
        count_star
            .evaluate()
            .unwrap()
            .as_any()
            .downcast_ref::<Int64Array>()
            .unwrap()
            .value(0),
        2
    );
    let mut overflowing_avg = executor(expression(
        AggregateFunction::Avg,
        DataType::Int64,
        DataType::Float64,
    ));
    overflowing_avg
        .merge(
            &[
                Arc::new(UInt64Array::from(vec![u64::MAX])),
                Arc::new(Float64Array::from(vec![0.0])),
            ],
            &[0],
            1,
        )
        .unwrap();
    overflowing_avg.update_single(&nulls).unwrap();
    assert!(
        overflowing_avg
            .update_single(&batch(Arc::new(Int64Array::from(vec![1]))))
            .is_err()
    );
}

#[test]
fn global_filter_excludes_errors_before_arguments_are_evaluated() {
    let input = RecordBatch::try_new(
        Arc::new(Schema::new(vec![
            Field::new("divisor", DataType::Int64, false),
            Field::new("keep", DataType::Boolean, true),
        ])),
        vec![
            Arc::new(Int64Array::from(vec![0, 2, 0, 4])),
            Arc::new(BooleanArray::from(vec![
                Some(false),
                Some(true),
                None,
                Some(true),
            ])),
        ],
    )
    .unwrap();
    let mut plan = TestPlan::new(&[(DataType::Int64, false), (DataType::Boolean, true)]);
    let eight = plan.column(DataType::Int64, false);
    let quotient = plan.column(DataType::Int64, false);
    let output = plan.column(DataType::Int64, true);
    let argument = FunctionExpression::binary(
        FunctionKind::Divide,
        ConstantExpression::int64(Some(8), eight).into_ref(),
        ReferenceExpression::new(plan.input(0)).into_ref(),
        quotient,
    )
    .into_ref();
    let filter = ReferenceExpression::new(plan.input(1)).into_ref();
    let mut sum = executor((
        plan,
        AggregateExpression::new(AggregateFunction::Sum, vec![argument], output)
            .with_filter(filter),
    ));
    sum.update_single(&input).unwrap();
    assert_eq!(
        sum.evaluate()
            .unwrap()
            .as_any()
            .downcast_ref::<Int64Array>()
            .unwrap()
            .value(0),
        6
    );
}

#[test]
fn grouped_sums_preserve_typed_state_and_sliced_null_bitmaps() {
    for array in [
        Arc::new(Int64Array::from(vec![
            Some(999),
            Some(i64::MAX),
            None,
            Some(1),
            Some(7),
            Some(-7),
        ])) as ArrayRef,
        Arc::new(UInt64Array::from(vec![
            Some(999),
            Some(u64::MAX),
            None,
            Some(1),
            Some(7),
            Some(1),
        ])),
        Arc::new(Float64Array::from(vec![
            Some(999.0),
            Some(4.0),
            None,
            Some(-4.0),
            Some(7.0),
            Some(1.0),
        ])),
    ] {
        let kind = array.data_type().clone();
        let mut sums = executor(expression(AggregateFunction::Sum, kind.clone(), kind));
        sums.update(&batch(array.slice(1, 5)), &[0, 1, 0, 2, 2], 4)
            .unwrap();
        let state = sums.state().unwrap();
        assert!(state[0].is_null(1));
        assert!(state[0].is_null(3));
        let output = sums.evaluate().unwrap();
        match output.data_type() {
            DataType::Int64 => assert_eq!(
                output.as_any().downcast_ref::<Int64Array>().unwrap(),
                &Int64Array::from(vec![Some(i64::MIN), None, Some(0), None])
            ),
            DataType::UInt64 => assert_eq!(
                output.as_any().downcast_ref::<UInt64Array>().unwrap(),
                &UInt64Array::from(vec![Some(0), None, Some(8), None])
            ),
            DataType::Float64 => assert_eq!(
                output.as_any().downcast_ref::<Float64Array>().unwrap(),
                &Float64Array::from(vec![Some(0.0), None, Some(8.0), None])
            ),
            _ => unreachable!(),
        }
        let mut merged = executor(expression(
            AggregateFunction::Sum,
            state[0].data_type().clone(),
            state[0].data_type().clone(),
        ));
        merged.merge(&state, &[3, 2, 1, 0], 4).unwrap();
        assert!(merged.evaluate().unwrap().is_null(0));
        assert!(merged.evaluate().unwrap().is_null(2));
    }
}

#[test]
fn public_grouped_update_still_rejects_invalid_ids() {
    let mut sum = executor(expression(
        AggregateFunction::Sum,
        DataType::Int64,
        DataType::Int64,
    ));
    let input = batch(Arc::new(Int64Array::from(vec![1, 2])));
    assert!(sum.update(&input, &[0], 1).is_err());
    assert!(sum.update(&input, &[0, 1], 1).is_err());
    assert!(sum.update(&input, &[0, usize::MAX], 1).is_err());
}

#[test]
fn grouped_count_and_sum_cross_bitmap_words_without_reading_null_payloads() {
    use crate::arrow::buffer::NullBuffer;

    let values = (0..151).map(|index| index as i64 - 70).collect::<Vec<_>>();
    let valid = (0..151).map(|index| index % 7 != 0).collect::<Vec<_>>();
    let array = Arc::new(Int64Array::new(
        values.clone().into(),
        Some(NullBuffer::from(valid.clone())),
    )) as ArrayRef;
    let input = batch(array.slice(3, 143));
    let ids = (0..143).map(|index| index % 5).collect::<Vec<_>>();
    let mut expected_sums = [0i64; 5];
    let mut expected_counts = [0i64; 5];
    for (index, &id) in ids.iter().enumerate() {
        if valid[index + 3] {
            expected_sums[id] = expected_sums[id].wrapping_add(values[index + 3]);
            expected_counts[id] += 1;
        }
    }
    for (function, expected) in [
        (AggregateFunction::Sum, expected_sums),
        (AggregateFunction::Count, expected_counts),
    ] {
        let mut aggregate = executor(expression(function, DataType::Int64, DataType::Int64));
        aggregate.update(&input, &ids, 5).unwrap();
        assert_eq!(
            aggregate
                .evaluate()
                .unwrap()
                .as_any()
                .downcast_ref::<Int64Array>()
                .unwrap(),
            &Int64Array::from(expected.to_vec())
        );
    }
}

fn assert_float_aggregate_state_eq(
    single: &AccumulatorTestHarness,
    grouped: &AccumulatorTestHarness,
) {
    let bit_values = |values: ArrayRef| {
        values
            .as_any()
            .downcast_ref::<Float64Array>()
            .unwrap()
            .iter()
            .map(|value| value.map(f64::to_bits))
            .collect::<Vec<_>>()
    };
    assert_eq!(
        bit_values(single.evaluate().unwrap()),
        bit_values(grouped.evaluate().unwrap())
    );
    for (single, grouped) in single
        .state()
        .unwrap()
        .into_iter()
        .zip(grouped.state().unwrap())
    {
        if single.data_type() == &DataType::Float64 {
            assert_eq!(bit_values(single), bit_values(grouped));
        } else {
            assert_eq!(single.to_data(), grouped.to_data());
        }
    }
}

#[test]
fn global_float_sum_keeps_first_negative_zero_and_ignores_null_payloads() {
    use crate::arrow::buffer::NullBuffer;

    let expr = expression(AggregateFunction::Sum, DataType::Float64, DataType::Float64);
    let mut single = executor(expr.clone());
    let mut grouped = executor(expr);
    let nulls = batch(Arc::new(Float64Array::from(vec![None, None])));
    single.update_single(&nulls).unwrap();
    grouped.update(&nulls, &[0, 0], 1).unwrap();
    assert!(single.evaluate().unwrap().is_null(0));
    assert_float_aggregate_state_eq(&single, &grouped);

    // NULL payloads contain NaNs and may not participate in the reduction.
    let array: ArrayRef = Arc::new(Float64Array::new(
        vec![123.0, f64::NAN, -0.0, f64::NAN].into(),
        Some(NullBuffer::from(vec![true, false, true, false])),
    ));
    let input = batch(array.slice(1, 3));
    single.update_single(&input).unwrap();
    grouped.update(&input, &[0, 0, 0], 1).unwrap();
    assert_float_aggregate_state_eq(&single, &grouped);
    assert_eq!(
        single
            .evaluate()
            .unwrap()
            .as_any()
            .downcast_ref::<Float64Array>()
            .unwrap()
            .value(0)
            .to_bits(),
        (-0.0f64).to_bits()
    );

    for input in [nulls, input.slice(0, 0)] {
        single.update_single(&input).unwrap();
        grouped
            .update(&input, &vec![0; input.num_rows()], 1)
            .unwrap();
        assert_float_aggregate_state_eq(&single, &grouped);
    }
}

#[test]
fn global_float_sum_and_avg_keep_grouped_order_across_batches_and_merge() {
    for function in [AggregateFunction::Sum, AggregateFunction::Avg] {
        for chunks in [
            vec![vec![Some(1e16), Some(1.0), Some(-1e16)]],
            vec![vec![Some(1e16)], vec![Some(1.0), None, Some(-1e16)]],
            vec![vec![Some(-0.0)], vec![None, Some(-0.0)]],
            vec![vec![
                Some(1e16),
                Some(1.0),
                Some(-1e16),
                Some(2.0),
                Some(1e16),
                None,
                Some(1.0),
                Some(-1e16),
                Some(4.0),
            ]],
        ] {
            let expr = expression(function, DataType::Float64, DataType::Float64);
            let mut single = executor(expr.clone());
            let mut grouped = executor(expr.clone());
            for chunk in chunks {
                let input = batch(Arc::new(Float64Array::from(chunk)));
                single.update_single(&input).unwrap();
                grouped
                    .update(&input, &vec![0; input.num_rows()], 1)
                    .unwrap();
                assert_float_aggregate_state_eq(&single, &grouped);
            }
            let mut merged_single = executor(expr.clone());
            let mut merged_grouped = executor(expr);
            merged_single
                .merge(&single.state().unwrap(), &[0], 1)
                .unwrap();
            merged_grouped
                .merge(&grouped.state().unwrap(), &[0], 1)
                .unwrap();
            let tail = batch(Arc::new(Float64Array::from(vec![
                Some(1.0),
                None,
                Some(-1e16),
            ])));
            merged_single.update_single(&tail).unwrap();
            merged_grouped.update(&tail, &[0, 0, 0], 1).unwrap();
            assert_float_aggregate_state_eq(&merged_single, &merged_grouped);
        }
    }
}
