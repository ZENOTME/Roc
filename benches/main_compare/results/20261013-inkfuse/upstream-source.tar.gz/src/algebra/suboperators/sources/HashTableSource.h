#ifndef INKFUSE_HASHTABLESOURCE_H
#define INKFUSE_HASHTABLESOURCE_H

#include "algebra/CompilationContext.h"
#include "algebra/RelAlgOp.h"
#include "algebra/suboperators/Suboperator.h"
#include "codegen/IRBuilder.h"
#include "runtime/NewHashTables.h"

namespace inkfuse {

/// Runtime state of the hash table source.
struct HashTableSourceState {
   static const char* name;

   /// Register the HashTableSourceState in the global inkfuse runtime.
   static void registerRuntime();

   /// Backing hash table from which we want to read.
   void* hash_table = nullptr;
   /// Iterator pointer at which to start.
   char* it_ptr_start = nullptr;
   /// Current iterator index.
   uint64_t it_idx_start;
   /// Iterator pointer at which to end.
   char* it_ptr_end = nullptr;
   /// Iterator end index.
   uint64_t it_idx_end;
};

/// The HashTableSouce allows reading from an underlying hash table. It returns char pointers to the
/// hash table payloads.
/// Picks morsels until all hash table payloads were produced. Within a single morsel, produces at most
/// DEFAULT_CHUNK_SIZE elements.
template <class HashTable>
struct HashTableSource : public TemplatedSuboperator<HashTableSourceState> {
   static SuboperatorArc build(const RelAlgOp* source, const IU& produced_iu, DefferredStateInitializer* deferred_state_);
   static SuboperatorArc buildForOuterJoin(const RelAlgOp* source, const IU& produced_iu, const IU& null_marker, DefferredStateInitializer* deferred_state_);

   /// Keep running as long as we have cells to read from in the backing hash table.
   PickMorselResult pickMorsel(size_t thread_id) override;

   void open(CompilationContext& context) override;

   void close(CompilationContext& context) override;

   std::string id() const override;

   protected:
   HashTableSource(const RelAlgOp* source, const IU& produced_iu, const IU* produced_null_markers, DefferredStateInitializer* deferred_state_);

   void setUpStateImpl(const ExecutionContext& context) override;

   private:
   /// In-flight while loop being generated between calls to open() and close().
   std::optional<IR::While> opt_while;
   /// Global state copied into the function preamble.
   IR::Stmt* decl_ht;
   IR::Stmt* decl_it_idx;
   /// The hash table we are reading from.
   DefferredStateInitializer* deferred_state;
};

using SimpleHashTableSource = HashTableSource<HashTableSimpleKey>;
using ComplexHashTableSource = HashTableSource<HashTableComplexKey>;
using DirectLookupHashTableSource = HashTableSource<HashTableDirectLookup>;
using AtomicHashTableSource = HashTableSource<AtomicHashTable<SimpleKeyComparator>>;
}

#endif //INKFUSE_HASHTABLESOURCE_H
